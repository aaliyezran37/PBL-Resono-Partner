document.addEventListener('DOMContentLoaded', function() {
  // Sidebar navigation
  const sidebarButtons = document.querySelectorAll('.sidebar-button');
  const pageContents = document.querySelectorAll('.page-content');

  // Function to show the selected page and hide others
  function showPage(pageId) {
      pageContents.forEach(content => {
          content.style.display = content.id === pageId ? 'block' : 'none';
      });
  }

  // Add click event listeners to sidebar buttons
  sidebarButtons.forEach(button => {
      button.addEventListener('click', function() {
          sidebarButtons.forEach(btn => btn.classList.remove('active'));
          this.classList.add('active');

          const pageId = this.id;
          showPage(pageId);
      });
  });

  // Set the initial content to the homepage
  showPage('homepage'); // Show homepage by default
  document.getElementById('homepage').classList.add('active'); // Set homepage button as active
});

// Function to load song details and simulate a new page
function loadSong(songId) {
  const songs = {
      song1: {
          title: "Blinding Lights",
          artist: "The Weeknd",
          lyrics: "I've been tryna call... (full lyrics here)"
      },
      song2: {
          title: "Watermelon Sugar",
          artist: "Harry Styles",
          lyrics: "Tastes like strawberries... (full lyrics here)"
      },
      song3: {
          title: "Levitating",
          artist: "Dua Lipa",
          lyrics: "You want me, I want you, baby... (full lyrics here)"
      }
  };

  const song = songs[songId];
  if (song) {
      // Update the main content area with the song details
      const contentArea = document.getElementById('contentArea');
      contentArea.innerHTML = `
          <div class="page-content" id="songDetails">
              <h1>${song.title}</h1>
              <h2>${song.artist}</h2>
              <p>${song.lyrics}</p>
              <button onclick="goBack()">Back to Home</button>
          </div>
      `;
  }
}

// Function to go back to the homepage
function goBack() {
  const contentArea = document.getElementById('contentArea');
  contentArea.innerHTML = `
      <div id="homepage" class="page-content">
          <h1>Welcome to Resono</h1>
          <p>Discover and enjoy your favorite music.</p>
      </div>
  `;
}
// Function to handle profile button click
function handleProfileClick() {
  const isLoggedIn = localStorage.getItem('loggedIn');

  if (isLoggedIn !== 'true') {
      alert('Please log in to view your profile information.'); // Alert message
  } else {
      console.log('Navigating to profile page...'); // Placeholder for actual navigation
  }
}

// Check if user is logged in
const isLoggedIn = localStorage.getItem('loggedIn');

// Function to update UI based on login state
function updateUI() {
  const isLoggedIn = localStorage.getItem('loggedIn') === 'true';
  const loginButton = document.getElementById('loginButton');
  const signupButton = document.getElementById('signupButton');
  const notificationButton = document.getElementById('notificationButton');
  const settingsButton = document.getElementById('settingsButton');

  if (isLoggedIn) {
      console.log('logged in');
      loginButton.style.display = 'none';
      signupButton.style.display = 'none';
      notificationButton.style.display = 'block';
      settingsButton.style.display = 'block';
  } else {
      console.log('not logged in');
      loginButton.style.display = 'block';
      signupButton.style.display = 'block';
      notificationButton.style.display = 'none';
      settingsButton.style.display = 'none';
  }
}

// Call updateUI on page load
window.onload = updateUI;












document.getElementById('darkModeToggle').addEventListener('click', function() {
    // Toggle dark mode class on the body
    document.body.classList.toggle('dark-mode');

    // Select elements to toggle dark mode
    const sidebar = document.querySelector('.sidebar');
    const sidebarButtons = document.querySelectorAll('.sidebar-button');
    const buttons = document.querySelectorAll('.button');
    const inputs = document.querySelectorAll('input');
    const links = document.querySelectorAll('a');
    const cards = document.querySelectorAll('.song-card, .playlist-card, .artist-card, .genre-card');
    const songList = document.querySelector('.song-list'); // Assuming you have a class for the song list
    const songItems = document.querySelectorAll('.song-item'); // Assuming you have a class for song items
    const searchBar = document.querySelector('.search-bar'); // Select the search bar
    const explorePage = document.querySelector('.explore-page'); // Select the explore page
    const playlistsPage = document.querySelector('.playlists-page'); // Select the playlists page

    // Toggle dark mode class on sidebar and buttons
    sidebar.classList.toggle('dark-mode');
    sidebarButtons.forEach(button => {
        button.classList.toggle('dark-mode');
    });
    buttons.forEach(button => {
        button.classList.toggle('dark-mode');
    });
    inputs.forEach(input => {
        input.classList.toggle('dark-mode');
    });
    links.forEach(link => {
        link.classList.toggle('dark-mode');
    });
    cards.forEach(card => {
        card.classList.toggle('dark-mode');
    });
    if (songList) {
        songList.classList.toggle('dark-mode'); // Toggle dark mode for song list
    }
    songItems.forEach(item => {
        item.classList.toggle('dark-mode'); // Toggle dark mode for song items
    });
    if (searchBar) {
        searchBar.classList.toggle('dark-mode'); // Toggle dark mode for search bar
    }
    if (explorePage) {
        explorePage.classList.toggle('dark-mode'); // Toggle dark mode for explore page
    }
    if (playlistsPage) {
        playlistsPage.classList.toggle('dark-mode'); // Toggle dark mode for playlists page
    }

    // Change the icon based on the mode
    if (document.body.classList.contains('dark-mode')) {
        this.classList.remove('fa-moon'); // Remove moon icon
        this.classList.add('fa-sun'); // Add sun icon
    } else {
        this.classList.remove('fa-sun'); // Remove sun icon
        this.classList.add('fa-moon'); // Add moon icon
    }

    // Save user preference in localStorage
    if (document.body.classList.contains('dark-mode')) {
        localStorage.setItem('darkMode', 'enabled');
    } else {
        localStorage.setItem('darkMode', 'disabled');
    }
});

// Check for saved user preference on page load
if (localStorage.getItem('darkMode') === 'enabled') {
    document.body.classList.add('dark-mode');
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.add('dark-mode');
    const sidebarButtons = document.querySelectorAll('.sidebar-button');
    sidebarButtons.forEach(button => {
        button.classList.add('dark-mode');
    });
    const buttons = document.querySelectorAll('.button');
    buttons.forEach(button => {
        button.classList.add('dark-mode');
    });
    const inputs = document.querySelectorAll('input');
    inputs.forEach(input => {
        input.classList.add('dark-mode');
    });
    const links = document.querySelectorAll('a');
    links.forEach(link => {
        link.classList.add('dark-mode');
    });
    const cards = document.querySelectorAll('.song-card, .playlist-card, .artist-card, .genre-card');
    cards.forEach(card => {
        card.classList.add('dark-mode');
    });
    const songList = document.querySelector('.song-list');
    if (songList) {
        songList.classList.add('dark-mode'); // Add dark mode to song list on load
    }
    const songItems = document.querySelectorAll('.song-item');
    songItems.forEach(item => {
        item.classList.add('dark-mode'); // Add dark mode to song items on load
    });
    const searchBar = document.querySelector('.search-bar');
    if (searchBar) {
        searchBar.classList.add('dark-mode'); // Add dark mode to search bar on load
    }
    const explorePage = document.querySelector('.explore-page');
    if (explorePage) {
        explorePage.classList.add('dark-mode'); // Add dark mode to explore page on load
    }
    const playlistsPage = document.querySelector('.playlists-page');
    if (playlistsPage) {
        playlistsPage.classList.add('dark-mode'); // Add dark mode to playlists page on load
    }

    // Set the icon to sun if dark mode is enabled
    document.getElementById('darkModeToggle').classList.remove('fa-moon');
    document.getElementById('darkModeToggle').classList.add('fa-sun');
}