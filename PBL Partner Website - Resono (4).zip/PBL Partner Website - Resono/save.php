<?php
// Database credentials
$servername = "127.0.0.1"; // Hostname/IP address
$username = "root"; // Username
$password = ""; // Your password
$dbname = "users"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $birthday = $_POST["birthday"];
    $dname = $_POST["dname"];
    $username = $_POST["username"];
    $password = $_POST["pword"];
    $genre1 = $_POST["genre1"];
    $genre2 = $_POST["genre2"];
    $genre3 = $_POST["genre3"];

    // Validate form data
    $nameErr = "";
    $birthdayErr = "";
    $usernameErr = "";
    $passwordErr = "";

    if (empty($name)) {
        $nameErr = "Name is required.";
    }

    if (empty($birthday)) {
        $birthdayErr = "Birthday is required.";
    } elseif (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $birthday)) {
        $birthdayErr = "Invalid birthday format. Please use YYYY-MM-DD.";
    }

    if (empty($username)) {
        $usernameErr = "Username is required.";
    } elseif (!preg_match("/^@/", $username)) {
        $usernameErr = "Username must start with '@'.";
    }

    if (empty($password)) {
        $passwordErr = "Password is required.";
    }

    // If there are no errors, proceed to insert data into the database
    if (empty($nameErr) && empty($birthdayErr) && empty($usernameErr) && empty($passwordErr)) {
        // Prepare and execute the SQL statement
        $stmt = $conn->prepare("INSERT INTO users (name, birthday, display_name, username, password, genre1, genre2, genre3, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssssssss", $name, $birthday, $dname, $username, $hashedPassword, $genre1, $genre2, $genre3);

        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        if ($stmt->execute()) {
            echo "Record added successfully!";
        } else {
            echo "Error executing query: " . $stmt->error;
        }

        $stmt->close();
    } else {
        // Display error messages to the user
        echo "<p><strong>Errors:</strong></p>";
        if (!empty($nameErr)) {
            echo "<p>$nameErr</p>";
        }
        if (!empty($birthdayErr)) {
            echo "<p>$birthdayErr</p>";
        }
        if (!empty($usernameErr)) {
            echo "<p>$usernameErr</p>";
        }
        if (!empty($passwordErr)) {
            echo "<p>$passwordErr</p>";
        }
    }
}

// Close the database connection
$conn->close();
?>