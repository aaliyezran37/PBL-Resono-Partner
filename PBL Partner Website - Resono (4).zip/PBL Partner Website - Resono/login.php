<?php
// Connect to the database
$servername = "127.0.0.1"; // Hostname/IP address
$username = "root"; // Username
$password = ""; // Your password
$dbname = "users"; // Database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get login form data
$nameOrDname = $_POST['nameOrDname'];
$username = $_POST['username'];
$password = $_POST['password'];

// Prepare SQL query to fetch the user record
$sql = "SELECT * FROM users WHERE (name = ? OR display_name = ?) AND username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $nameOrDname, $nameOrDname, $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Fetch user data
    $user = $result->fetch_assoc();

    // Verify password
    if (password_verify($password, $user['password'])) {
        echo "Login successful! Welcome, " . htmlspecialchars($user['display_name'] ?? $user['name']) . ".";
        // You can start a session here
        // session_start();
        // $_SESSION['user'] = $user;
    } else {
        echo "Invalid password.";
    }
} else {
    echo "Invalid credentials. Please try again.";
}

$stmt->close();
$conn->close();
?>
